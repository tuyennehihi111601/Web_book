package com.oop.btlon1.service.mail;

public interface EmailService {
    void send(String to, String content);
}