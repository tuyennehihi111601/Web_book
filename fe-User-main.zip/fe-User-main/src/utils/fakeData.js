export const contentFood = [
    {
        id: '1',
        header: '⭐️ DEADLINE DZÍ, XÍ DEAL XỊN ⭐️',
        content: " Anh em tranh thủ ghé Lẩu Phan vào mỗi thứ 3 hàng tuần để nhận ngay buffet 33k nhá 📌 Set kèo ăn...",
        img: 'https://cdn.lauphan.com/photo-storage/myFile-1650424268076.jpeg',
        avt: 'https://lauphan.com/WebLauPhan/tinuudai/logo-phan.svg',
    },
    {
        id: '1',
        header: '⭐️ DEADLINE DZÍ, XÍ DEAL XỊN ⭐️',
        content: " Anh em tranh thủ ghé Lẩu Phan vào mỗi thứ 3 hàng tuần để nhận ngay buffet 33k nhá 📌 Set kèo ăn...",
        img: 'https://cdn.lauphan.com/photo-storage/myFile-1650422570145.jpeg',
        avt: 'https://lauphan.com/WebLauPhan/tinuudai/logo-phan.svg',
    },
    {
        id: '1',
        header: '⭐️ DEADLINE DZÍ, XÍ DEAL XỊN ⭐️',
        content: " Anh em tranh thủ ghé Lẩu Phan vào mỗi thứ 3 hàng tuần để nhận ngay buffet 33k nhá 📌 Set kèo ăn...",
        img: 'https://cdn.lauphan.com/photo-storage/myFile-1650338052715.jpeg',
        avt: 'https://lauphan.com/WebLauPhan/tinuudai/logo-phan.svg',
    },
    {
        id: '1',
        header: '⭐️ DEADLINE DZÍ, XÍ DEAL XỊN ⭐️',
        content: " Anh em tranh thủ ghé Lẩu Phan vào mỗi thứ 3 hàng tuần để nhận ngay buffet 33k nhá 📌 Set kèo ăn...",
        img: 'https://cdn.lauphan.com/photo-storage/myFile-1641441790289.jpeg',
        avt: 'https://lauphan.com/WebLauPhan/tinuudai/logo-phan.svg',
    },
    {
        id: '1',
        header: '⭐️ DEADLINE DZÍ, XÍ DEAL XỊN ⭐️',
        content: " Anh em tranh thủ ghé Lẩu Phan vào mỗi thứ 3 hàng tuần để nhận ngay buffet 33k nhá 📌 Set kèo ăn...",
        img: 'https://cdn.lauphan.com/photo-storage/myFile-1646362218388.jpeg',
        avt: 'https://lauphan.com/WebLauPhan/tinuudai/logo-phan.svg',
    },
    {
        id: '1',
        header: '⭐️ DEADLINE DZÍ, XÍ DEAL XỊN ⭐️',
        content: " Anh em tranh thủ ghé Lẩu Phan vào mỗi thứ 3 hàng tuần để nhận ngay buffet 33k nhá 📌 Set kèo ăn...",
        img: 'https://cdn.lauphan.com/photo-storage/myFile-1649313007261.png',
        avt: 'https://lauphan.com/WebLauPhan/tinuudai/logo-phan.svg',
    },
]

export const combo = [
    {
        id: 1,
        img: 'https://cdn.lauphan.com/photo-storage/myFile-1643523231113.jpeg'
    },
    {
        id: 2,
        img: 'https://cdn.lauphan.com/photo-storage/myFile-1643523242290.jpeg'
    },
    {
        id: 3,
        img: 'https://cdn.lauphan.com/photo-storage/myFile-1643523250854.jpeg'
    },
    {
        id: 4,
        img: 'https://cdn.lauphan.com/photo-storage/myFile-1639712466932.jpeg'
    },
    {
        id: 5,
        img: 'https://cdn.lauphan.com/photo-storage/myFile-1617849775218.jpeg'
    }
]

export const listFood = [
    {
        id: 1,
        name: 'Bò lúc lắc sốt tiêu đen',
        description: 'Định lượng: 300g',
        image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
        quanity: 0,
        price: 105000
    },
    {
        id: 2,
        name: 'Bò lúc lắc sốt tiêu đen',
        description: 'Định lượng: 300g',
        image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
        quanity: 0,
        price: 105000
    },
    {
        id: 3,
        name: 'Bò lúc lắc sốt tiêu đen',
        description: 'Định lượng: 300g',
        image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
        quanity: 0,
        price: 105000
    },
    {
        id: 4,
        name: 'Bò lúc lắc sốt tiêu đen',
        description: 'Định lượng: 300g',
        image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
        quanity: 0,
        price: 105000
    },
    {
        id: 5,
        name: 'Bò lúc lắc sốt tiêu đen',
        description: 'Định lượng: 300g',
        image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
        quanity: 0,
        price: 105000
    },
    {
        id: 6,
        name: 'Bò lúc lắc sốt tiêu đen',
        description: 'Định lượng: 300g',
        image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
        quanity: 0,
        price: 105000
    },
];

export const date = ['Hôm nay', 'Ngày mai', 'Ngày kia'];
export const numberPp = [1, 2, 3, 4, 5, 6, 7, 8];
export const time = [
    '10:00',
    '11:00',
    '10:00',
    '10:00',
    '10:00',
    '10:00',
    '10:00',
    '10:00',
    '10:00',
    '10:00',
    '10:00',
    '10:00',
    '10:00',
    '10:00',
    '10:00',
]

export const content = [
    'Tải app, nhập mã BBDL nhận ưu đãi lên tới hơn 300K: http://phanexpress.com/taiapp',
    'Gạt hết đủ thể loại deadline sang một bên, tụ tập tới Phan nhúng lẩu cùng đồng nghiệp, anh em mà còn được giảm đậm với đầy đủ: ',
    '⭐️ 3 vị nước lẩu độc quyền: Lẩu Thái, Lẩu Kim Chi, Lẩu Chua Sấu xì xụp xì xụp.',
    '⭐️ Khai vị hấp dẫn: bánh gà phô mai, hoành thánh phô mai, gà sốt xí muội, chả bò ngô, salad rong biển trứng cua,... ăn là ghiền.',
    '⭐️ Đồ nhúng tươi ngon, đa dạng từ bắp bò, gầu bò đến tim heo, gà đùi,... ',
    'Ăn là ghiền, đặt bàn liền, đừng bỏ lỡ !!!',
    '🔻 Nội dung chương trình ',
    '- Giảm giá cho khách hàng khi đi với nhóm từ 4 người trở lên khi nhập mã code BBDL tại app Phan Express. Áp dụng theo lũy kế cụ thể:',
    '. Giảm 100k cho bàn đi từ 4 khách trở lên',
    '. Giảm 100k cho bàn đi từ 4 khách trở lên',
    '. Giảm 100k cho bàn đi từ 4 khách trở lên',
    '🔻  Điều kiện áp dụng',
    '- Áp dụng cho bàn từ 4 người trở lên',
    '- Áp dụng cho buổi trưa 11h-14h : Thứ 2, Thứ 4 và Thứ 5',
    '- Áp dụng cho tất cả các cơ sở Lẩu Phan ở Hà Nội',
    '- Không áp dụng vào ngày lễ  (02/05)',
    '- Không áp dụng cùng CTKM và các loại thẻ khác',
    '- Áp dụng cùng gói decor sinh nhật',
    '🔻Thời gian áp dụng',
    '- Từ 11h00 ngày 20/4/2022 đến hết ngày 5/5/2022',
    '⏰ Giờ phục vụ: ',
    'Thứ 2 - Thứ 5: Trưa: 11h - 14h/ Tối: 18h - 23h',
    'Thứ 6 - Chủ Nhật: All day 11h - 23h',
    '☎️ Hotline đặt bàn: 19002808',
    '🌐 Website đặt bàn: lauphan.com'
]

export const url = ['/login', '/signup', '/order', '/book', '/bill', '/userinfo', '/history/bill', '/history/book', '/detail-bill'];

export const rows = [
    {
        dishes: [
            {
                name: 'Bò lúc lắc sốt tiêu đen',
                description: 'Định lượng: 300g',
                image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
                quanity: 0,
                price: 105000
            },
            {
                name: 'Bò lúc lắc sốt tiêu đen',
                description: 'Định lượng: 300g',
                image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
                quanity: 0,
                price: 105000
            },
            {
                name: 'Bò lúc lắc sốt tiêu đen',
                description: 'Định lượng: 300g',
                image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
                quanity: 0,
                price: 105000
            },
        ],
        quantity: [1, 2, 1],
        name: 'Than Van Long',
        createAt: new Date().toLocaleDateString(),
        deliveryAt: new Date().toLocaleDateString(),
        total: 1000000,
    },

    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 6,
    //     name: 'Long Van Than',
    //     createAt: new Date(2022, 4, 29).toLocaleDateString(),
    //     deliveryAt: new Date().toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // },
    // {
    //     data: {
    //         name: 'Bò lúc lắc sốt tiêu đen',
    //         description: 'Định lượng: 300g',
    //         image: 'https://cdn.lauphan.com/photo-storage/myFile-1640706124113.jpeg',
    //         quanity: 0,
    //         price: 105000
    //     },
    //     quantity: 4,
    //     name: 'Nguyen Van A',
    //     createAt: new Date(2022, 4, 23).toLocaleDateString(),
    //     deliveryAt: new Date(2022, 2, 9).toLocaleDateString(),
    //     total: 1100000,
    // }
]