export const editable = {
  btnEdit: true,
  btnDelete: true,
  btnAdd: true,
};
