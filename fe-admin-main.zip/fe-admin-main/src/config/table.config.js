export const fieldName = {
  book: [
    'Id',
    'Name',
    'Author',
    'Company',
    'Img Url',
    'Page Count',
    'Published Date',
  ],
  order: ['Id', 'Name', 'Address', 'PhoneNumber', 'Status'],
};
